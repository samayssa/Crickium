from __future__ import annotations
import html
from handlers.registry import register, register_callback
from app import app
from database.query import fetchrow
from database.play_repo import get_active_match_in_chat as get_play_match_in_chat, get_active_match_for_user as get_play_match_for_user
from database.playint_repo import get_active_match_in_chat as get_playint_match_in_chat, get_active_match_for_user as get_playint_match_for_user
from database.playwpl_repo import create_match,get_match,set_message_id,update_status,get_active_match_in_chat,get_active_match_for_user
from buttons.playwpl_buttons import challenge_keyboard
from utils.mentions import mention, mention_html
from utils.timers import start_timer, cancel_timer
from engines.match_engine import challenge_expired_message
from .teams import send_team_selection


def _challenge_text(a,o):
    return ("<b>╭━━〔 🏏 WPL MATCH 〕━━╮\n\n"
            f"⚔️ {a}\n              VS\n🔥 {o}\n\n</b>"
            "<blockquote><b>🏏 Women's Premier League\n🌍 Franchise Squads</b></blockquote>\n\n"
            "<b>💬 WPL challenge received!\n\n"
            "Choose your WPL franchise, build your Playing XI,\n"
            "and battle for the win! 🏆🔥\n\n"
            "╰━━━━━━━━━━━━━━━━━━╯</b>")


def parse_target(text):
    parts=(text or '').split()
    for p in parts[1:]:
        if p.startswith('@') and len(p)>1: return ('username',p[1:])
        if p.isdigit(): return ('id',int(p))
    return None

@register('playwpl')
async def playwpl_command(message):
    chat_id=int(message['chat']['id']); u=message.get('from',{}); challenger_id=int(u.get('id'))
    active=await get_active_match_in_chat(chat_id)
    if active:
        await app.send_message(chat_id,'<b>⚠️ A PlayWPL game is already going on in this group.</b>',parse_mode='HTML'); return
    active_play=await get_play_match_in_chat(chat_id)
    if active_play:
        await app.send_message(chat_id,'<b>⚠️ A game is already going on in this group. Finish it before starting a PlayWPL game.</b>',parse_mode='HTML'); return
    active_playint=await get_playint_match_in_chat(chat_id)
    if active_playint:
        await app.send_message(chat_id,'<b>⚠️ A PlayInt game is already going on in this group. Finish it before starting a PlayWPL game.</b>',parse_mode='HTML'); return
    active=await get_active_match_for_user(challenger_id)
    if active:
        await app.send_message(chat_id,"<b>⚠️ You're already in a game. Please finish it first.</b>",parse_mode='HTML'); return
    if await get_play_match_for_user(challenger_id):
        await app.send_message(chat_id,"<b>⚠️ You're already in another game. Please finish it first.</b>",parse_mode='HTML'); return
    if await get_playint_match_for_user(challenger_id):
        await app.send_message(chat_id,"<b>⚠️ You're already in a PlayInt game. Please finish it first.</b>",parse_mode='HTML'); return

    reply=(message.get('reply_to_message') or {}).get('from') or {}
    target=None
    if reply.get('id'):
        if reply.get('is_bot'):
            await app.send_message(chat_id,'<b>⚠️ You can\'t challenge a bot!</b>',parse_mode='HTML'); return
        target=(int(reply['id']),reply.get('username'),reply.get('first_name'))
    else:
        parsed=parse_target(message.get('text',''))
        if parsed is None:
            await app.send_message(chat_id,'<b>⚠️ To challenge someone, reply to their message with /playwpl, use /playwpl @username, or use /playwpl USER_ID.</b>',parse_mode='HTML'); return
        kind,val=parsed
        if kind=='username': row=await fetchrow('SELECT user_id, username, first_name FROM users WHERE LOWER(username)=LOWER($1) LIMIT 1;',val)
        else: row=await fetchrow('SELECT user_id, username, first_name FROM users WHERE user_id=$1;',val)
        if not row:
            await app.send_message(chat_id,'<b>⚠️ I could not find that user. Ask them to use the bot first.</b>',parse_mode='HTML'); return
        target=(int(row['user_id']),row['username'],row['first_name'])
    opponent_id, opponent_username, opponent_name = target
    if opponent_id==challenger_id:
        await app.send_message(chat_id,"<b>⚠️ You can't challenge yourself!</b>",parse_mode='HTML'); return
    if await get_active_match_for_user(opponent_id):
        om=mention_html(opponent_id,opponent_username,opponent_name)
        await app.send_message(chat_id,f'<b>⚠️ {om} is already in another game.</b>',parse_mode='HTML'); return
    if await get_play_match_for_user(opponent_id):
        om=mention_html(opponent_id,opponent_username,opponent_name)
        await app.send_message(chat_id,f'<b>⚠️ {om} is already in another game.</b>',parse_mode='HTML'); return
    if await get_playint_match_for_user(opponent_id):
        om=mention_html(opponent_id,opponent_username,opponent_name)
        await app.send_message(chat_id,f'<b>⚠️ {om} is already in a PlayInt game.</b>',parse_mode='HTML'); return

    match=await create_match(chat_id,challenger_id,u.get('username'),u.get('first_name'),opponent_id,opponent_username,opponent_name)
    a=mention_html(challenger_id,u.get('username'),u.get('first_name')); o=mention_html(opponent_id,opponent_username,opponent_name)
    sent=await app.send_message(chat_id,_challenge_text(a,o),parse_mode='HTML',reply_markup=challenge_keyboard(match['match_id']))
    await set_message_id(match['match_id'],sent['message_id'])

    challenge_id = int(match['match_id'])
    async def on_reminder(remaining):
        return None

    async def on_timeout():
        current = await get_match(challenge_id)
        if not current or current['status'] != 'pending':
            return
        await update_status(challenge_id, 'expired')
        await app.edit_message_text(
            chat_id,
            sent['message_id'],
            challenge_expired_message(
                mention(current['challenger_id'], current['challenger_username'], current['challenger_name']),
                mention(current['opponent_id'], current['opponent_username'], current['opponent_name']),
            ),
            parse_mode='Markdown',
            reply_markup={'inline_keyboard': []},
        )

    start_timer('challenge', challenge_id, on_reminder, on_timeout, total_seconds=60)

@register_callback('playwpl_accept')
async def playwpl_accept(callback_query):
    mid=int(callback_query['data'].split(':')[1]); presser=callback_query['from']; msg=callback_query['message']; match=await get_match(mid)
    if not match or match['status']!='pending':
        await app.answer_callback_query(callback_query['id'],'This challenge is no longer active.',show_alert=True); return
    if int(presser['id'])!=int(match['opponent_id']):
        await app.answer_callback_query(callback_query['id'],"This challenge isn't for you!",show_alert=True); return
    if await get_play_match_for_user(int(presser['id'])):
        await app.answer_callback_query(callback_query['id'],"You're already in another game. Finish it first.",show_alert=True); return
    await update_status(mid,'accepted'); cancel_timer('challenge', mid); await app.answer_callback_query(callback_query['id'],'Challenge accepted!')
    a=mention_html(match['challenger_id'],match['challenger_username'],match['challenger_name']); o=mention_html(match['opponent_id'],match['opponent_username'],match['opponent_name'])
    text=("<b>╭━━〔 🏏 WPL MATCH 〕━━╮\n\n" f"⚔️ {a}\n              VS\n🔥 {o}\n\n</b>"
          "<blockquote><b>🏏 Women's Premier League\n🌍 Franchise Squads</b></blockquote>\n\n"
          "✅ <b>Challenge Accepted!</b>\n\nGet ready to choose your WPL franchise. 🏏🔥\n\n"
          "<b>╰━━━━━━━━━━━━━━━━━━╯</b>")
    # Publish the next stage first.  The challenge message was originally
    # sent through the Bot API because it contains styled buttons; editing it
    # through the MTProto client can fail on some Kurigram/Telegram paths.
    # A cleanup failure must never prevent the newly published team-selection
    # stage from appearing.
    await send_team_selection(msg['chat']['id'], match)
    try:
        await app.edit_message_text(
            msg['chat']['id'], msg['message_id'], text,
            parse_mode='HTML', reply_markup={'inline_keyboard': []},
        )
    except Exception as cleanup_exc:
        print(f"[playwpl] accepted-challenge cleanup edit failed for match_id={mid}: {cleanup_exc!r}")

@register_callback('playwpl_decline')
async def playwpl_decline(callback_query):
    mid=int(callback_query['data'].split(':')[1]); presser=callback_query['from']; msg=callback_query['message']; match=await get_match(mid)
    if not match or match['status']!='pending':
        await app.answer_callback_query(callback_query['id'],'This challenge is no longer active.',show_alert=True); return
    if int(presser['id'])!=int(match['opponent_id']):
        await app.answer_callback_query(callback_query['id'],"This challenge isn't for you!",show_alert=True); return
    await update_status(mid,'declined'); cancel_timer('challenge', mid); await app.answer_callback_query(callback_query['id'],'Challenge declined.')
    a=mention_html(match['challenger_id'],match['challenger_username'],match['challenger_name']); o=mention_html(match['opponent_id'],match['opponent_username'],match['opponent_name'])
    text=("<b>╭━━〔 🏏 WPL MATCH 〕━━╮\n\n" f"⚔️ {a}\n              VS\n🔥 {o}\n\n</b>"
          "<blockquote><b>🏏 Women's Premier League\n🌍 Franchise Squads</b></blockquote>\n\n"
          "❌ <b>Challenge Declined!</b>\n\nMaybe next time. 🏏\n\n"
          "<b>╰━━━━━━━━━━━━━━━━━━╯</b>")
    await app.edit_message_text(msg['chat']['id'],msg['message_id'],text,parse_mode='HTML',reply_markup={'inline_keyboard':[]})
