from database.query import execute

TABLES = {
    "playint_players": """
        CREATE TABLE IF NOT EXISTS playint_players(
            player_id SERIAL PRIMARY KEY,
            engine_key TEXT NOT NULL DEFAULT 'T20I',
            team_code TEXT NOT NULL,
            team_name TEXT NOT NULL,
            name TEXT NOT NULL,
            country TEXT,
            role TEXT NOT NULL,
            bat_level INTEGER NOT NULL,
            bowl_level INTEGER NOT NULL,
            batting_hand TEXT,
            bowling_hand TEXT,
            uploaded_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW(),
            UNIQUE(engine_key, team_code, name)
        );
    """,
    "playint_matches": """
        CREATE TABLE IF NOT EXISTS playint_matches(
            match_id SERIAL PRIMARY KEY,
            chat_id BIGINT NOT NULL,
            message_id BIGINT,
            challenger_id BIGINT NOT NULL,
            challenger_username TEXT,
            challenger_name TEXT,
            opponent_id BIGINT NOT NULL,
            opponent_username TEXT,
            opponent_name TEXT,
            challenger_team_code TEXT,
            challenger_team_name TEXT,
            opponent_team_code TEXT,
            opponent_team_name TEXT,
            challenger_xi JSONB NOT NULL DEFAULT '[]'::jsonb,
            opponent_xi JSONB NOT NULL DEFAULT '[]'::jsonb,
            challenger_xi_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
            opponent_xi_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
            status TEXT DEFAULT 'pending',
            pitch TEXT,
            toss_winner_id BIGINT,
            toss_call TEXT,
            toss_result TEXT,
            decision TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "schema_version": """
        CREATE TABLE IF NOT EXISTS schema_version(
            id SERIAL PRIMARY KEY,
            version INTEGER NOT NULL,
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "bot_runtime_state": """
        CREATE TABLE IF NOT EXISTS bot_runtime_state(
            state_key TEXT PRIMARY KEY,
            state_value TEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "users": """
        CREATE TABLE IF NOT EXISTS users(
            user_id BIGINT PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            balance BIGINT DEFAULT 0,
            total_spent BIGINT DEFAULT 0,
            captain_player_id BIGINT,
            created_at TIMESTAMP DEFAULT NOW(),
            last_seen_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "recent_playing_xis": """
        CREATE TABLE IF NOT EXISTS recent_playing_xis(
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            engine_key TEXT NOT NULL,
            team_code TEXT NOT NULL,
            player_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
            updated_at TIMESTAMP DEFAULT NOW(),
            PRIMARY KEY (user_id, engine_key, team_code)
        );
    """,
    "matches": """
        CREATE TABLE IF NOT EXISTS matches(
            match_id SERIAL PRIMARY KEY,
            creator BIGINT,
            status TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "player_stats": """
        CREATE TABLE IF NOT EXISTS player_stats(
            user_id BIGINT PRIMARY KEY,
            matches INTEGER DEFAULT 0,
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            runs INTEGER DEFAULT 0,
            wickets INTEGER DEFAULT 0
        );
    """,
    "players": """
        CREATE TABLE IF NOT EXISTS players(
            player_id SERIAL PRIMARY KEY,
            name TEXT NOT NULL UNIQUE,
            country TEXT,
            role TEXT NOT NULL,
            bat_level INTEGER NOT NULL,
            bowl_level INTEGER NOT NULL,
            batting_hand TEXT,
            bowling_hand TEXT,
            uploaded_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "team_squads": """
        CREATE TABLE IF NOT EXISTS team_squads(
            user_id BIGINT PRIMARY KEY REFERENCES users(user_id),
            squad JSONB NOT NULL,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "referrals": """
        CREATE TABLE IF NOT EXISTS referrals(
            referral_id BIGSERIAL PRIMARY KEY,
            referrer_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            referred_id BIGINT NOT NULL UNIQUE REFERENCES users(user_id) ON DELETE CASCADE,
            status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed')),
            debut_completed BOOLEAN NOT NULL DEFAULT FALSE,
            claim_completed BOOLEAN NOT NULL DEFAULT FALSE,
            game_completed BOOLEAN NOT NULL DEFAULT FALSE,
            reward_number INTEGER,
            reward_coins BIGINT NOT NULL DEFAULT 0,
            reward_rubies BIGINT NOT NULL DEFAULT 0,
            reward_players JSONB NOT NULL DEFAULT '[]'::jsonb,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            completed_at TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        );
    """,
    "match_challenges": """
        CREATE TABLE IF NOT EXISTS match_challenges(
            challenge_id SERIAL PRIMARY KEY,
            chat_id BIGINT NOT NULL,
            message_id BIGINT,
            challenger_id BIGINT NOT NULL,
            challenger_username TEXT,
            challenger_name TEXT,
            opponent_id BIGINT,
            opponent_username TEXT,
            opponent_name TEXT,
            format TEXT DEFAULT 'T20',
            status TEXT DEFAULT 'pending',
            toss_winner_id BIGINT,
            toss_call TEXT,
            toss_result TEXT,
            decision TEXT,
            created_at TIMESTAMP DEFAULT NOW(),
            expires_at TIMESTAMP
        );
    """,
    "player_claims": """
        CREATE TABLE IF NOT EXISTS player_claims(
            claim_id SERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            player_id BIGINT NOT NULL REFERENCES players(player_id),
            status TEXT DEFAULT 'pending',
            claimed_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "player_user_match_stats": """
        CREATE TABLE IF NOT EXISTS player_user_match_stats(
            match_id BIGINT NOT NULL,
            user_id BIGINT NOT NULL REFERENCES users(user_id),
            player_id BIGINT NOT NULL REFERENCES players(player_id),
            bat_matches INTEGER NOT NULL DEFAULT 0,
            bat_innings INTEGER NOT NULL DEFAULT 0,
            runs INTEGER NOT NULL DEFAULT 0,
            fifties INTEGER NOT NULL DEFAULT 0,
            centuries INTEGER NOT NULL DEFAULT 0,
            bat_balls INTEGER NOT NULL DEFAULT 0,
            dismissals INTEGER NOT NULL DEFAULT 0,
            bowl_matches INTEGER NOT NULL DEFAULT 0,
            bowl_innings INTEGER NOT NULL DEFAULT 0,
            wickets INTEGER NOT NULL DEFAULT 0,
            three_wickets INTEGER NOT NULL DEFAULT 0,
            five_wickets INTEGER NOT NULL DEFAULT 0,
            bowl_balls INTEGER NOT NULL DEFAULT 0,
            bowl_runs INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT NOW(),
            PRIMARY KEY (match_id, user_id, player_id)
        );
    """,
    "broadcast_targets": """
        CREATE TABLE IF NOT EXISTS broadcast_targets(
            chat_id BIGINT PRIMARY KEY,
            target_type TEXT NOT NULL,
            title TEXT,
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "team_lineups": """
        CREATE TABLE IF NOT EXISTS team_lineups(
            user_id BIGINT PRIMARY KEY REFERENCES users(user_id),
            player_ids JSONB NOT NULL,
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "miniapp_news_articles": """
        CREATE TABLE IF NOT EXISTS miniapp_news_articles(
            article_id BIGSERIAL PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            image_file_id TEXT NOT NULL,
            created_by BIGINT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            is_published BOOLEAN NOT NULL DEFAULT TRUE
        );
    """,
    "probability_profiles": """
        CREATE TABLE IF NOT EXISTS probability_profiles(
            profile_id SERIAL PRIMARY KEY,
            profile_key TEXT NOT NULL UNIQUE,
            selectors JSONB NOT NULL DEFAULT '{}'::jsonb,
            probabilities JSONB NOT NULL DEFAULT '{}'::jsonb,
            outcomes JSONB NOT NULL DEFAULT '{}'::jsonb,
            duplicate_counts JSONB NOT NULL DEFAULT '{}'::jsonb,
            created_by BIGINT,
            updated_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "special_edition_players": """
        CREATE TABLE IF NOT EXISTS special_edition_players(
            special_player_id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            edition TEXT NOT NULL,
            country TEXT,
            role TEXT NOT NULL,
            bat_level INTEGER NOT NULL,
            bowl_level INTEGER NOT NULL,
            batting_hand TEXT,
            bowling_hand TEXT,
            uploaded_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "special_player_card_images": """
        CREATE TABLE IF NOT EXISTS special_player_card_images(
            special_player_id BIGINT PRIMARY KEY REFERENCES special_edition_players(special_player_id) ON DELETE CASCADE,
            file_id TEXT NOT NULL,
            channel_message_id BIGINT,
            uploaded_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "showcase_sets": """
        CREATE TABLE IF NOT EXISTS showcase_sets(
            showcase_set_id BIGSERIAL PRIMARY KEY,
            set_name TEXT NOT NULL UNIQUE,
            set_slug TEXT NOT NULL UNIQUE,
            status TEXT NOT NULL DEFAULT 'active',
            uploaded_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "showcase_cards": """
        CREATE TABLE IF NOT EXISTS showcase_cards(
            showcase_card_id BIGSERIAL PRIMARY KEY,
            showcase_set_id BIGINT NOT NULL REFERENCES showcase_sets(showcase_set_id) ON DELETE CASCADE,
            name TEXT NOT NULL,
            country TEXT,
            role TEXT NOT NULL,
            bat_level INTEGER NOT NULL,
            bowl_level INTEGER NOT NULL,
            batting_hand TEXT,
            bowling_hand TEXT,
            base_player_id BIGINT,
            uploaded_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW(),
            UNIQUE(showcase_set_id, name)
        );
    """,
    "showcase_player_card_images": """
        CREATE TABLE IF NOT EXISTS showcase_player_card_images(
            showcase_card_id BIGINT PRIMARY KEY REFERENCES showcase_cards(showcase_card_id) ON DELETE CASCADE,
            file_id TEXT NOT NULL,
            channel_message_id BIGINT,
            uploaded_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "authorized_uploaders": """
        CREATE TABLE IF NOT EXISTS authorized_uploaders(
            user_id BIGINT PRIMARY KEY,
            granted_by BIGINT NOT NULL,
            granted_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "player_card_images": """
        CREATE TABLE IF NOT EXISTS player_card_images(
            player_id BIGINT PRIMARY KEY REFERENCES players(player_id),
            file_id TEXT NOT NULL,
            channel_message_id BIGINT,
            uploaded_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "template_card_image": """
        CREATE TABLE IF NOT EXISTS template_card_image(
            id INTEGER PRIMARY KEY,
            card_type TEXT,
            file_id TEXT NOT NULL,
            channel_message_id BIGINT,
            uploaded_by BIGINT,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """,
    # Dedicated to the /play command's own challenge -> pitch -> toss ->
    # decision -> lineup flow. Kept entirely separate from
    # match_challenges (used by /match) so nothing about /match changes.
    "play_matches": """
        CREATE TABLE IF NOT EXISTS play_matches(
            match_id SERIAL PRIMARY KEY,
            chat_id BIGINT NOT NULL,
            message_id BIGINT,
            challenger_id BIGINT NOT NULL,
            challenger_username TEXT,
            challenger_name TEXT,
            opponent_id BIGINT NOT NULL,
            opponent_username TEXT,
            opponent_name TEXT,
            status TEXT DEFAULT 'pending',
            pitch TEXT,
            toss_winner_id BIGINT,
            toss_call TEXT,
            toss_result TEXT,
            decision TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """,
    # PLAYSO is a first-class persisted runtime table. It used to be
    # created lazily by database/playso_repo.py, which made hot game traffic
    # run CREATE TABLE checks against Neon. Keep the schema centralized here.
    "playso_matches": """
        CREATE TABLE IF NOT EXISTS playso_matches(
            match_id SERIAL PRIMARY KEY,
            chat_id BIGINT NOT NULL,
            message_id BIGINT,
            challenger_id BIGINT NOT NULL,
            challenger_username TEXT,
            challenger_name TEXT,
            opponent_id BIGINT NOT NULL,
            opponent_username TEXT,
            opponent_name TEXT,
            status TEXT NOT NULL DEFAULT 'pending',
            pitch TEXT,
            toss_winner_id BIGINT,
            toss_call TEXT,
            toss_result TEXT,
            decision TEXT,
            stadium TEXT,
            weather TEXT,
            innings_no INTEGER NOT NULL DEFAULT 1,
            state JSONB NOT NULL DEFAULT '{}'::jsonb,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            expires_at TIMESTAMP
        );
    """,
    "playipl_matches": """
        CREATE TABLE IF NOT EXISTS playipl_matches(
            match_id SERIAL PRIMARY KEY,
            chat_id BIGINT NOT NULL,
            message_id BIGINT,
            challenger_id BIGINT NOT NULL,
            challenger_username TEXT,
            challenger_name TEXT,
            opponent_id BIGINT NOT NULL,
            opponent_username TEXT,
            opponent_name TEXT,
            challenger_team_code TEXT,
            challenger_team_name TEXT,
            opponent_team_code TEXT,
            opponent_team_name TEXT,
            challenger_xi JSONB NOT NULL DEFAULT '[]'::jsonb,
            opponent_xi JSONB NOT NULL DEFAULT '[]'::jsonb,
            challenger_xi_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
            opponent_xi_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
            status TEXT DEFAULT 'pending',
            pitch TEXT,
            toss_winner_id BIGINT,
            toss_call TEXT,
            toss_result TEXT,
            decision TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "wpl_matches": """
        CREATE TABLE IF NOT EXISTS wpl_matches(
            match_id SERIAL PRIMARY KEY,
            chat_id BIGINT NOT NULL,
            message_id BIGINT,
            challenger_id BIGINT NOT NULL,
            challenger_username TEXT,
            challenger_name TEXT,
            opponent_id BIGINT NOT NULL,
            opponent_username TEXT,
            opponent_name TEXT,
            challenger_team_code TEXT,
            challenger_team_name TEXT,
            opponent_team_code TEXT,
            opponent_team_name TEXT,
            challenger_xi JSONB NOT NULL DEFAULT '[]'::jsonb,
            opponent_xi JSONB NOT NULL DEFAULT '[]'::jsonb,
            challenger_xi_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
            opponent_xi_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
            status TEXT DEFAULT 'pending',
            pitch TEXT,
            toss_winner_id BIGINT,
            toss_call TEXT,
            toss_result TEXT,
            decision TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """,
    "match_analysis_counter": """
        CREATE TABLE IF NOT EXISTS match_analysis_counter(
            counter_id SMALLINT PRIMARY KEY,
            last_number BIGINT NOT NULL DEFAULT 0
        );
    """,
    "match_analysis_reports": """
        CREATE TABLE IF NOT EXISTS match_analysis_reports(
            report_id BIGSERIAL PRIMARY KEY,
            engine TEXT NOT NULL,
            source_match_id BIGINT NOT NULL,
            match_number BIGINT NOT NULL UNIQUE,
            filename TEXT NOT NULL,
            termination TEXT NOT NULL,
            sent BOOLEAN NOT NULL DEFAULT FALSE,
            telegram_message_id BIGINT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            sent_at TIMESTAMPTZ,
            UNIQUE(engine, source_match_id)
        );
    """,
    "game_session_snapshots": """
        CREATE TABLE IF NOT EXISTS game_session_snapshots(
            engine TEXT NOT NULL,
            match_id BIGINT NOT NULL,
            payload BYTEA NOT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
            PRIMARY KEY (engine, match_id)
        );
    """,
    # Caches one Telegram file_id per stadium name, so /play's MATCH
    # READY card only has to search + download a stadium photo once -
    # every later match at that same stadium reuses the saved file_id.
    "stadium_images": """
        CREATE TABLE IF NOT EXISTS stadium_images(
            stadium_name TEXT PRIMARY KEY,
            file_id TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """,
}


async def migrate():
    print("Checking database...")

    for table_name, ddl in TABLES.items():
        print(f"[migrate] Ensuring table '{table_name}' exists...")
        await execute(ddl)
        print(f"[migrate] Table '{table_name}' OK.")

    print("[migrate] Ensuring runtime match indexes...")
    await execute("CREATE INDEX IF NOT EXISTS idx_match_analysis_reports_engine ON match_analysis_reports(engine,source_match_id);")
    await execute("CREATE INDEX IF NOT EXISTS idx_playso_matches_chat_status ON playso_matches(chat_id,status);")
    await execute("CREATE INDEX IF NOT EXISTS idx_playso_matches_user_status ON playso_matches(challenger_id,opponent_id,status);")
    await execute("CREATE INDEX IF NOT EXISTS idx_playipl_matches_chat_status ON playipl_matches(chat_id,status);")
    await execute("CREATE INDEX IF NOT EXISTS idx_playipl_matches_user_status ON playipl_matches(challenger_id,opponent_id,status);")
    await execute("CREATE INDEX IF NOT EXISTS idx_wpl_matches_chat_status ON wpl_matches(chat_id,status);")
    await execute("CREATE INDEX IF NOT EXISTS idx_wpl_matches_user_status ON wpl_matches(challenger_id,opponent_id,status);")
    print("[migrate] Runtime match indexes OK.")

    print("[migrate] Ensuring 'users.claim_attempt_at' column exists...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS claim_attempt_at TIMESTAMP;")
    print("[migrate] 'users.claim_attempt_at' OK.")

    print("[migrate] Ensuring 'users.last_seen_at' column exists...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS last_seen_at TIMESTAMP DEFAULT NOW();")
    print("[migrate] 'users.last_seen_at' OK.")

    print("[migrate] Ensuring 'users.captain_player_id' column exists...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS captain_player_id BIGINT;")
    print("[migrate] 'users.captain_player_id' OK.")

    print("[migrate] Ensuring index on players.role exists...")
    await execute("CREATE INDEX IF NOT EXISTS idx_players_role ON players(role);")
    print("[migrate] idx_players_role OK.")

    print("[migrate] Ensuring unique index on special-edition identity...")
    await execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_special_edition_identity ON special_edition_players(LOWER(name), LOWER(edition));")
    await execute("CREATE INDEX IF NOT EXISTS idx_special_edition_name ON special_edition_players(LOWER(name));")
    await execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_showcase_set_name ON showcase_sets(LOWER(set_name));")
    await execute("CREATE INDEX IF NOT EXISTS idx_showcase_cards_name ON showcase_cards(LOWER(name));")
    await execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_showcase_card_identity ON showcase_cards(showcase_set_id, LOWER(name));")
    await execute("CREATE INDEX IF NOT EXISTS idx_showcase_cards_set ON showcase_cards(showcase_set_id, showcase_card_id);")
    await execute("CREATE INDEX IF NOT EXISTS idx_showcase_card_images_card ON showcase_player_card_images(showcase_card_id);")
    await execute("CREATE INDEX IF NOT EXISTS idx_miniapp_news_articles_published ON miniapp_news_articles(is_published, created_at DESC);")
    print("[migrate] Mini App news table/index OK.")

    print("[migrate] special-edition indexes OK.")

    print("[migrate] Ensuring 'player_claims.chat_id' column exists...")
    await execute("ALTER TABLE player_claims ADD COLUMN IF NOT EXISTS chat_id BIGINT;")
    print("[migrate] 'player_claims.chat_id' OK.")

    print("[migrate] Ensuring 'player_claims.message_id' column exists...")
    await execute("ALTER TABLE player_claims ADD COLUMN IF NOT EXISTS message_id BIGINT;")
    print("[migrate] 'player_claims.message_id' OK.")

    print("[migrate] Ensuring index on player_claims.user_id exists...")
    await execute("CREATE INDEX IF NOT EXISTS idx_player_claims_user ON player_claims(user_id, claimed_at);")
    print("[migrate] idx_player_claims_user OK.")

    print("[migrate] Ensuring index on probability_profiles.profile_key exists...")
    await execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_probability_profiles_key ON probability_profiles(profile_key);")
    print("[migrate] idx_probability_profiles_key OK.")

    print("[migrate] Ensuring 'players.batting_hand' column exists...")
    await execute("ALTER TABLE players ADD COLUMN IF NOT EXISTS batting_hand TEXT;")
    print("[migrate] 'players.batting_hand' OK.")

    print("[migrate] Ensuring 'players.bowling_hand' column exists...")
    await execute("ALTER TABLE players ADD COLUMN IF NOT EXISTS bowling_hand TEXT;")
    print("[migrate] 'players.bowling_hand' OK.")

    print("[migrate] Ensuring 'users.total_spent' column exists...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS total_spent BIGINT DEFAULT 0;")
    print("[migrate] 'users.total_spent' OK.")

    print("[migrate] Ensuring 'users.rubies' column exists...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS rubies BIGINT DEFAULT 0;")
    print("[migrate] 'users.rubies' OK.")

    print("[migrate] Ensuring Quest and Pack economy columns...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS sigils BIGINT DEFAULT 0;")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS total_sigils_spent BIGINT DEFAULT 0;")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS total_sigils_earned BIGINT DEFAULT 0;")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS total_rubies_spent BIGINT DEFAULT 0;")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS total_rubies_earned BIGINT DEFAULT 0;")
    print("[migrate] Quest and Pack economy columns OK.")

    print("[migrate] Ensuring Crickium Quest tables exist...")
    await execute("""
        CREATE TABLE IF NOT EXISTS quest_periods(
            period_type TEXT NOT NULL CHECK (period_type IN ('daily','weekly','monthly')),
            period_key TEXT NOT NULL,
            start_at TIMESTAMPTZ NOT NULL,
            end_at TIMESTAMPTZ NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY(period_type, period_key)
        );
    """)
    await execute("""
        CREATE TABLE IF NOT EXISTS quest_user_assignments(
            period_type TEXT NOT NULL CHECK (period_type IN ('daily','weekly','monthly')),
            period_key TEXT NOT NULL,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            task_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
            fingerprint TEXT NOT NULL,
            assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY(period_type, period_key, user_id),
            UNIQUE(period_type, period_key, fingerprint)
        );
    """)
    await execute("""
        CREATE TABLE IF NOT EXISTS quest_completions(
            completion_id UUID PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            period_type TEXT NOT NULL,
            period_key TEXT NOT NULL,
            task_id TEXT NOT NULL,
            sigils BIGINT NOT NULL DEFAULT 0,
            coins BIGINT NOT NULL DEFAULT 0,
            rubies BIGINT NOT NULL DEFAULT 0,
            completed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            UNIQUE(user_id, period_type, period_key, task_id)
        );
    """)
    await execute("""
        CREATE TABLE IF NOT EXISTS quest_events(
            event_id UUID PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            event_type TEXT NOT NULL,
            value_int BIGINT NOT NULL DEFAULT 0,
            metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
            occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
    """)
    await execute("""
        CREATE TABLE IF NOT EXISTS quest_match_summaries(
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            engine TEXT NOT NULL,
            match_id BIGINT NOT NULL,
            match_type TEXT NOT NULL DEFAULT '',
            pitch TEXT,
            won BOOLEAN NOT NULL DEFAULT FALSE,
            chasing BOOLEAN NOT NULL DEFAULT FALSE,
            defending BOOLEAN NOT NULL DEFAULT FALSE,
            late_chase BOOLEAN NOT NULL DEFAULT FALSE,
            comeback_chase BOOLEAN NOT NULL DEFAULT FALSE,
            comeback_defense BOOLEAN NOT NULL DEFAULT FALSE,
            target INTEGER NOT NULL DEFAULT 0,
            batting_runs BIGINT NOT NULL DEFAULT 0,
            bowling_wickets BIGINT NOT NULL DEFAULT 0,
            conceded_boundary BOOLEAN NOT NULL DEFAULT FALSE,
            batting JSONB NOT NULL DEFAULT '{}'::jsonb,
            bowling JSONB NOT NULL DEFAULT '{}'::jsonb,
            over_history JSONB NOT NULL DEFAULT '[]'::jsonb,
            played_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY(user_id, engine, match_id)
        );
    """)
    await execute("CREATE INDEX IF NOT EXISTS idx_quest_events_user_time ON quest_events(user_id, occurred_at DESC);")
    await execute("CREATE INDEX IF NOT EXISTS idx_quest_events_user_type_time ON quest_events(user_id, event_type, occurred_at DESC);")
    await execute("CREATE INDEX IF NOT EXISTS idx_quest_completions_user_period ON quest_completions(user_id, period_type, period_key);")
    await execute("CREATE INDEX IF NOT EXISTS idx_quest_summaries_user_time ON quest_match_summaries(user_id, played_at DESC);")
    print("[migrate] Crickium Quest tables OK.")

    print("[migrate] Ensuring Crickium Pack tables exist...")
    await execute("""
        CREATE TABLE IF NOT EXISTS pack_inventory(
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            pack_key TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY(user_id, pack_key)
        );
    """)
    await execute("""
        CREATE TABLE IF NOT EXISTS pack_purchase_requests(
            request_id UUID PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            pack_key TEXT NOT NULL,
            price_sigils BIGINT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','cancelled','failed')),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            processed_at TIMESTAMPTZ
        );
    """)
    await execute("CREATE INDEX IF NOT EXISTS idx_pack_purchase_requests_user_status ON pack_purchase_requests(user_id, status, created_at DESC);")
    await execute("ALTER TABLE pack_purchase_requests ADD COLUMN IF NOT EXISTS client_request_id TEXT;")
    await execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_pack_purchase_requests_user_client_request ON pack_purchase_requests(user_id,client_request_id) WHERE client_request_id IS NOT NULL;")
    await execute("""
        CREATE TABLE IF NOT EXISTS pack_openings(
            opening_id UUID PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            pack_key TEXT NOT NULL,
            cards JSONB NOT NULL DEFAULT '[]'::jsonb,
            coins BIGINT NOT NULL DEFAULT 0,
            rubies BIGINT NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'opened',
            opened_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
    """)
    await execute("CREATE INDEX IF NOT EXISTS idx_pack_openings_user_time ON pack_openings(user_id, opened_at DESC);")
    await execute("ALTER TABLE pack_openings ADD COLUMN IF NOT EXISTS client_request_id TEXT;")
    await execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_pack_openings_user_client_request ON pack_openings(user_id,client_request_id) WHERE client_request_id IS NOT NULL;")
    await execute("""
        CREATE TABLE IF NOT EXISTS pack_card_inventory(
            card_id BIGSERIAL PRIMARY KEY,
            opening_id UUID NOT NULL REFERENCES pack_openings(opening_id) ON DELETE CASCADE,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            player_id BIGINT NOT NULL,
            card_kind TEXT NOT NULL CHECK (card_kind IN ('core','bonus')),
            position INTEGER NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            UNIQUE(opening_id, position)
        );
    """)
    await execute("CREATE INDEX IF NOT EXISTS idx_pack_card_inventory_user ON pack_card_inventory(user_id, created_at DESC);")
    print("[migrate] Crickium Pack tables OK.")

    print("[migrate] Ensuring table 'daily_rewards' exists...")
    await execute(
        """
        CREATE TABLE IF NOT EXISTS daily_rewards(
            user_id BIGINT PRIMARY KEY REFERENCES users(user_id),
            streak INTEGER NOT NULL DEFAULT 0,
            total_claimed BIGINT NOT NULL DEFAULT 0,
            last_claim_at TIMESTAMP,
            next_claim_at TIMESTAMP,
            updated_at TIMESTAMP DEFAULT NOW()
        );
        """
    )
    print("[migrate] daily_rewards OK.")

    print("[migrate] Ensuring table 'probability_profiles' has required columns...")
    await execute("ALTER TABLE probability_profiles ADD COLUMN IF NOT EXISTS selectors JSONB NOT NULL DEFAULT '{}'::jsonb;")
    await execute("ALTER TABLE probability_profiles ADD COLUMN IF NOT EXISTS probabilities JSONB NOT NULL DEFAULT '{}'::jsonb;")
    await execute("ALTER TABLE probability_profiles ADD COLUMN IF NOT EXISTS outcomes JSONB NOT NULL DEFAULT '{}'::jsonb;")
    await execute("ALTER TABLE probability_profiles ADD COLUMN IF NOT EXISTS duplicate_counts JSONB NOT NULL DEFAULT '{}'::jsonb;")
    await execute("ALTER TABLE probability_profiles ADD COLUMN IF NOT EXISTS created_by BIGINT;")
    await execute("ALTER TABLE probability_profiles ADD COLUMN IF NOT EXISTS updated_by BIGINT;")
    await execute("ALTER TABLE probability_profiles ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT NOW();")
    await execute("ALTER TABLE probability_profiles ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW();")
    print("[migrate] probability_profiles columns OK.")

    print("[migrate] Upgrading 'template_card_image' to support separate bat/ball templates...")
    await execute("ALTER TABLE template_card_image DROP CONSTRAINT IF EXISTS template_card_image_single_row;")
    await execute("ALTER TABLE template_card_image ALTER COLUMN id DROP DEFAULT;")
    await execute("ALTER TABLE template_card_image ADD COLUMN IF NOT EXISTS card_type TEXT;")
    # Any pre-existing template (from the old single-template /upload_img
    # template flow) becomes the bat-card template, since that's what it
    # was always used for.
    await execute("UPDATE template_card_image SET card_type = 'bat' WHERE card_type IS NULL;")
    await execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_template_card_image_type ON template_card_image(card_type);")
    print("[migrate] 'template_card_image' upgrade OK.")

    # --- Ruby -> Coin exchange request ledger (one-time callback guard) ---
    print("[migrate] Ensuring table 'coin_exchange_requests' exists...")
    await execute(
        """
        CREATE TABLE IF NOT EXISTS coin_exchange_requests(
            request_id UUID PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            rubies BIGINT NOT NULL CHECK (rubies > 0),
            coins BIGINT NOT NULL CHECK (coins > 0),
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT NOW(),
            processed_at TIMESTAMP
        );
        """
    )
    await execute("CREATE INDEX IF NOT EXISTS idx_coin_exchange_requests_user ON coin_exchange_requests(user_id, created_at DESC);")
    print("[migrate] coin_exchange_requests OK.")

    # --- Level system (Level 1-30, 6 tiers) + franchise identity for /profile ---
    print("[migrate] Ensuring 'users.level' column exists...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS level INTEGER NOT NULL DEFAULT 1;")
    print("[migrate] 'users.level' OK.")

    print("[migrate] Ensuring 'users.xp' column exists...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS xp INTEGER NOT NULL DEFAULT 0;")
    print("[migrate] 'users.xp' OK.")

    print("[migrate] Ensuring 'users.franchise_name' column exists...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS franchise_name TEXT;")
    print("[migrate] 'users.franchise_name' OK.")
    print("[migrate] Ensuring user team-logo fields exist...")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS team_logo_type TEXT;")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS team_logo_id TEXT;")
    await execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS team_logo_fallback TEXT;")
    await execute("""
        CREATE TABLE IF NOT EXISTS team_logo_requests(
            token TEXT PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            logo_type TEXT NOT NULL,
            logo_id TEXT NOT NULL,
            logo_fallback TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """)
    await execute("CREATE INDEX IF NOT EXISTS idx_team_logo_requests_user ON team_logo_requests(user_id);")
    print("[migrate] user team-logo fields/table OK.")

    print("[migrate] Ensuring index for level/xp leaderboard ranking exists...")
    await execute("CREATE INDEX IF NOT EXISTS idx_users_level_xp ON users(level DESC, xp DESC);")
    print("[migrate] idx_users_level_xp OK.")
    await execute("CREATE INDEX IF NOT EXISTS idx_referrals_referrer_status ON referrals(referrer_id, status, created_at);")
    await execute("CREATE INDEX IF NOT EXISTS idx_referrals_referred_status ON referrals(referred_id, status);")
    print("[migrate] referral indexes OK.")

    # --- Tier card images uploaded via '/upload_img <tier>' (bronze/silver/gold/...) ---
    print("[migrate] Ensuring table 'tier_card_images' exists...")
    await execute(
        """
        CREATE TABLE IF NOT EXISTS tier_card_images(
            tier_key TEXT PRIMARY KEY,
            file_id TEXT NOT NULL,
            channel_message_id BIGINT,
            uploaded_by BIGINT,
            updated_at TIMESTAMP DEFAULT NOW()
        );
        """
    )
    print("[migrate] tier_card_images OK.")

    # --- Career batting/bowling stats for /plstats (cricket player cards,
    # NOT the same as user-level player_stats used by /profile's XP system) ---
    print("[migrate] Ensuring players career-stat columns exist...")
    await execute(
        """
        ALTER TABLE players
            ADD COLUMN IF NOT EXISTS bat_matches INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS bat_innings INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS runs INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS fifties INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS centuries INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS bat_average NUMERIC(8,2) NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS strike_rate NUMERIC(8,2) NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS bowl_matches INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS bowl_innings INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS wickets INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS three_wickets INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS five_wickets INTEGER NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS bowl_average NUMERIC(8,2) NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS economy NUMERIC(8,2) NOT NULL DEFAULT 0;
        """
    )
    print("[migrate] players career-stat columns OK.")

    # --- PlayInt engine/team scoped player storage ---
    # Existing PlayInt rows belong to the T20I engine. Keep them intact while
    # replacing the old team-only uniqueness rule with engine + team + name.
    print("[migrate] Ensuring playint_players engine scope...")
    await execute("ALTER TABLE playint_players ADD COLUMN IF NOT EXISTS engine_key TEXT NOT NULL DEFAULT 'T20I';")
    await execute("UPDATE playint_players SET engine_key='T20I' WHERE engine_key IS NULL OR engine_key='';")
    await execute("ALTER TABLE playint_players DROP CONSTRAINT IF EXISTS playint_players_team_code_name_key;")
    await execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_playint_players_engine_team_name ON playint_players(engine_key, team_code, name);")
    await execute("CREATE INDEX IF NOT EXISTS idx_playint_players_engine_team ON playint_players(engine_key, team_code);")
    print("[migrate] playint_players engine scope OK.")

    # /plstats stores the same signed squad-facing player_id used by team_squads.
    # Global players are positive IDs; special editions use the negative
    # special_player_id namespace. The old FK to players blocked all writes
    # whenever one special-edition player appeared in a match ledger.
    print("[migrate] Relaxing player_user_match_stats.player_id FK for global + special IDs...")
    await execute("ALTER TABLE player_user_match_stats DROP CONSTRAINT IF EXISTS player_user_match_stats_player_id_fkey;")
    print("[migrate] player_user_match_stats player identity constraint OK.")



    # --- Player upgrade system ---
    print("[migrate] Ensuring player upgrade tables exist...")
    await execute(
        """
        CREATE TABLE IF NOT EXISTS upgrade_catalog(
            upgrade_id SERIAL PRIMARY KEY,
            upgrade_key TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL UNIQUE,
            category TEXT NOT NULL,
            description TEXT NOT NULL,
            detail TEXT NOT NULL DEFAULT '',
            eligible_roles JSONB NOT NULL DEFAULT '[]'::jsonb,
            eligible_family TEXT,
            eligible_tactics JSONB NOT NULL DEFAULT '[]'::jsonb,
            eligible_phases JSONB NOT NULL DEFAULT '[]'::jsonb,
            target_approaches JSONB NOT NULL DEFAULT '[]'::jsonb,
            effect_config JSONB NOT NULL DEFAULT '{}'::jsonb,
            active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        );
        """
    )
    await execute(
        """
        CREATE TABLE IF NOT EXISTS upgrade_catalog_tiers(
            upgrade_id INTEGER NOT NULL REFERENCES upgrade_catalog(upgrade_id) ON DELETE CASCADE,
            tier SMALLINT NOT NULL CHECK (tier BETWEEN 1 AND 5),
            strength NUMERIC(5,4) NOT NULL,
            cost BIGINT NOT NULL CHECK (cost > 0),
            PRIMARY KEY (upgrade_id, tier)
        );
        """
    )
    await execute(
        """
        CREATE TABLE IF NOT EXISTS user_player_upgrades(
            id BIGSERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            player_id BIGINT NULL,
            player_kind TEXT NULL CHECK (player_kind IS NULL OR player_kind IN ('global','special','showcase')),
            upgrade_id INTEGER NOT NULL REFERENCES upgrade_catalog(upgrade_id) ON DELETE CASCADE,
            tier SMALLINT NOT NULL CHECK (tier BETWEEN 1 AND 5),
            owned_at TIMESTAMP NOT NULL DEFAULT NOW(),
            source TEXT NOT NULL DEFAULT 'shop',
            UNIQUE(user_id, upgrade_id, tier)
        );
        """
    )
    await execute(
        """
        CREATE TABLE IF NOT EXISTS user_player_loadouts(
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            player_id BIGINT NOT NULL,
            player_kind TEXT NOT NULL CHECK (player_kind IN ('global','special','showcase')),
            batting_upgrade_id INTEGER NULL REFERENCES upgrade_catalog(upgrade_id) ON DELETE SET NULL,
            bowling_upgrade_id INTEGER NULL REFERENCES upgrade_catalog(upgrade_id) ON DELETE SET NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
            PRIMARY KEY(user_id, player_id, player_kind)
        );
        """
    )
    await execute(
        """
        CREATE TABLE IF NOT EXISTS match_player_upgrade_snapshots(
            match_id BIGINT NOT NULL,
            user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            player_id BIGINT NOT NULL,
            player_kind TEXT NOT NULL,
            batting_upgrade_key TEXT,
            batting_tier SMALLINT,
            bowling_upgrade_key TEXT,
            bowling_tier SMALLINT,
            snapshot_json JSONB NOT NULL DEFAULT '{}'::jsonb,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            PRIMARY KEY(match_id, user_id, player_id, player_kind)
        );
        """
    )
    await execute("CREATE INDEX IF NOT EXISTS idx_user_player_upgrades_user_active ON user_player_upgrades(user_id, upgrade_id, tier);")
    await execute("CREATE INDEX IF NOT EXISTS idx_user_player_upgrades_user_player ON user_player_upgrades(user_id, player_id, player_kind);")
    await execute("CREATE INDEX IF NOT EXISTS idx_user_player_loadouts_user_player ON user_player_loadouts(user_id, player_id, player_kind);")
    await execute("CREATE INDEX IF NOT EXISTS idx_match_player_upgrade_snapshots_match_user ON match_player_upgrade_snapshots(match_id, user_id);")
    await execute("CREATE INDEX IF NOT EXISTS idx_upgrade_catalog_key_active ON upgrade_catalog(upgrade_key, active);")
    # Existing deployments were created with four-tier CHECK constraints.
    # Replace them in-place so old data remains valid while Tier V becomes available.
    await execute("ALTER TABLE upgrade_catalog_tiers DROP CONSTRAINT IF EXISTS upgrade_catalog_tiers_tier_check;")
    await execute("ALTER TABLE upgrade_catalog_tiers ADD CONSTRAINT upgrade_catalog_tiers_tier_check CHECK (tier BETWEEN 1 AND 5);")
    await execute("ALTER TABLE user_player_upgrades DROP CONSTRAINT IF EXISTS user_player_upgrades_tier_check;")
    await execute("ALTER TABLE user_player_upgrades ADD CONSTRAINT user_player_upgrades_tier_check CHECK (tier BETWEEN 1 AND 5);")
    await execute(
        """
        CREATE TABLE IF NOT EXISTS h2h_matches(
            match_id BIGINT PRIMARY KEY,
            user_low_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            user_high_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            winner_id BIGINT NULL REFERENCES users(user_id) ON DELETE SET NULL,
            recorded_at TIMESTAMP NOT NULL DEFAULT NOW(),
            CHECK (user_low_id < user_high_id),
            CHECK (winner_id IS NULL OR winner_id = user_low_id OR winner_id = user_high_id)
        );
        """
    )
    await execute("CREATE INDEX IF NOT EXISTS idx_h2h_pair ON h2h_matches(user_low_id, user_high_id);")
    await execute(
        """
        CREATE TABLE IF NOT EXISTS trade_requests(
            trade_id BIGSERIAL PRIMARY KEY,
            chat_id BIGINT NOT NULL,
            sender_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            recipient_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            sender_player_id BIGINT NOT NULL,
            sender_player_kind TEXT NOT NULL CHECK (sender_player_kind IN ('global','special','showcase')),
            recipient_player_id BIGINT NULL,
            recipient_player_kind TEXT NULL CHECK (recipient_player_kind IS NULL OR recipient_player_kind IN ('global','special','showcase')),
            sender_player_json JSONB NOT NULL,
            recipient_player_json JSONB NULL,
            status TEXT NOT NULL DEFAULT 'awaiting_sender' CHECK (status IN ('awaiting_sender','awaiting_recipient','completed','declined','cancelled','expired')),
            message_id BIGINT,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            expires_at TIMESTAMP NOT NULL,
            completed_at TIMESTAMP
        );
        """
    )
    await execute("CREATE INDEX IF NOT EXISTS idx_trade_sender_status ON trade_requests(sender_id, status);")
    await execute("CREATE INDEX IF NOT EXISTS idx_trade_recipient_status ON trade_requests(recipient_id, status);")

    # Allow the 'showcase' card kind in existing CHECK constraints. Done AFTER every table
    # exists (a fresh database used to fail here because trade_requests was altered before
    # it was created) and only when the live constraint does not already allow it, so
    # normal restarts do not re-validate these tables.
    for _table, _constraint, _check in (
        ("user_player_upgrades", "user_player_upgrades_player_kind_check", "player_kind IS NULL OR player_kind IN ('global','special','showcase')"),
        ("user_player_loadouts", "user_player_loadouts_player_kind_check", "player_kind IN ('global','special','showcase')"),
        ("trade_requests", "trade_requests_sender_player_kind_check", "sender_player_kind IN ('global','special','showcase')"),
        ("trade_requests", "trade_requests_recipient_player_kind_check", "recipient_player_kind IS NULL OR recipient_player_kind IN ('global','special','showcase')"),
    ):
        await execute(f"""
            DO $do$
            BEGIN
                IF NOT EXISTS (
                    SELECT 1 FROM pg_constraint
                    WHERE conname = '{_constraint}' AND conrelid = '{_table}'::regclass
                      AND pg_get_constraintdef(oid) LIKE '%showcase%'
                ) THEN
                    ALTER TABLE {_table} DROP CONSTRAINT IF EXISTS {_constraint};
                    ALTER TABLE {_table} ADD CONSTRAINT {_constraint} CHECK ({_check});
                END IF;
            END
            $do$;
        """)
    print("[migrate] Player upgrade tables OK.")

    from services.player_upgrades import UPGRADES
    from utils.upgrade_prices import UPGRADE_RUBY_PRICES, TIER_STRENGTHS
    import json as _json
    import hashlib as _hashlib

    # Seeding is ~150 statements. Skip it when the catalogue definition is unchanged
    # since the last successful seed (fingerprint kept in bot_runtime_state) and the
    # table still holds every upgrade, so routine restarts do not wake Neon for it.
    from database.query import fetchval as _fetchval
    _seed_fingerprint = _hashlib.sha256(_json.dumps(
        [[u.key, u.name, u.category, u.description, u.detail, sorted(u.roles), u.family,
          sorted(u.tactics), sorted(u.phases), sorted(u.approaches), u.effect_kind,
          list(u.outcomes), list(u.fund_from), sorted(u.counter_approaches)] for u in UPGRADES]
        + [sorted((int(k), float(v)) for k, v in TIER_STRENGTHS.items()),
           sorted((int(k), int(v)) for k, v in UPGRADE_RUBY_PRICES.items())],
        default=str, sort_keys=True,
    ).encode("utf-8")).hexdigest()
    _stored_fingerprint = await _fetchval("SELECT state_value FROM bot_runtime_state WHERE state_key='upgrade_catalog_seed';")
    _seeded_rows = await _fetchval("SELECT COUNT(*) FROM upgrade_catalog WHERE active;")
    _skip_seed = _stored_fingerprint == _seed_fingerprint and int(_seeded_rows or 0) >= len(UPGRADES)
    if _skip_seed:
        print("[migrate] Player upgrade catalogue unchanged; seeding skipped.")
    for upgrade in ([] if _skip_seed else UPGRADES):
        await execute(
            """
            INSERT INTO upgrade_catalog(
                upgrade_key,name,category,description,detail,eligible_roles,eligible_family,eligible_tactics,eligible_phases,target_approaches,effect_config,active
            ) VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7,$8::jsonb,$9::jsonb,$10::jsonb,$11::jsonb,TRUE)
            ON CONFLICT (upgrade_key) DO UPDATE SET
                name=EXCLUDED.name, category=EXCLUDED.category, description=EXCLUDED.description, detail=EXCLUDED.detail,
                eligible_roles=EXCLUDED.eligible_roles, eligible_family=EXCLUDED.eligible_family, eligible_tactics=EXCLUDED.eligible_tactics,
                eligible_phases=EXCLUDED.eligible_phases, target_approaches=EXCLUDED.target_approaches, effect_config=EXCLUDED.effect_config,
                updated_at=NOW();
            """,
            upgrade.key, upgrade.name, upgrade.category, upgrade.description, upgrade.detail,
            _json.dumps(sorted(upgrade.roles)), upgrade.family, _json.dumps(sorted(upgrade.tactics)),
            _json.dumps(sorted(upgrade.phases)), _json.dumps(sorted(upgrade.approaches)),
            _json.dumps({"effect_kind": upgrade.effect_kind, "outcomes": list(upgrade.outcomes), "fund_from": list(upgrade.fund_from), "counter_approaches": sorted(upgrade.counter_approaches)}),
        )
        # Read the seeded catalogue ID through fetchval before inserting tier rows.
        from database.query import fetchval
        upgrade_id = await fetchval("SELECT upgrade_id FROM upgrade_catalog WHERE upgrade_key=$1;", upgrade.key)
        for tier, strength in TIER_STRENGTHS.items():
            await execute(
                """
                INSERT INTO upgrade_catalog_tiers(upgrade_id,tier,strength,cost) VALUES($1,$2,$3,$4)
                ON CONFLICT (upgrade_id,tier) DO UPDATE SET strength=EXCLUDED.strength,cost=EXCLUDED.cost;
                """,
                int(upgrade_id), int(tier), float(strength), int(UPGRADE_RUBY_PRICES[tier]),
            )
    if not _skip_seed:
        await execute(
            "INSERT INTO bot_runtime_state(state_key,state_value,updated_at) VALUES('upgrade_catalog_seed',$1,NOW()) "
            "ON CONFLICT(state_key) DO UPDATE SET state_value=EXCLUDED.state_value, updated_at=NOW();",
            _seed_fingerprint,
        )
    print("[migrate] Player upgrade catalogue seeded.")

    try:
        from database import achievements_repo, giveaway_repo, miniapp_game_repo
        await achievements_repo.ensure_schema()
        await miniapp_game_repo.ensure_schema()
        await giveaway_repo.ensure_schema()
        print("[migrate] Achievements + Play Game tables OK.")
    except Exception as exc:
        print(f"[migrate] Achievements/Play Game schema skipped: {exc!r}")

    try:
        from database import tournament_repo
        await tournament_repo.ensure_schema()
        print("[migrate] Tournament + auction tables OK.")
    except Exception as exc:
        print(f"[migrate] Tournament schema skipped: {exc!r}")

    print("Migration Complete.")
